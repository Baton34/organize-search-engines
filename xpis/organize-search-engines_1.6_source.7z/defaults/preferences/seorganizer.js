pref("extensions.seorganizer.sortDirection", "natural");
pref("extensions.organize-search-engines@maltekraus.de.description",
     "chrome://seorganizer/locale/desc.properties");